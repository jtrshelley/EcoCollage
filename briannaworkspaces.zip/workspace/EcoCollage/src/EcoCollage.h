/*
 * EcoCollage.h
 *
 *  Created on: Jul 11, 2013
 *      Author: brianna
 */

#ifndef ECOCOLLAGE_H_
#define ECOCOLLAGE_H_

class EcoCollage {
public:
	EcoCollage();
	virtual ~EcoCollage();
};

#endif /* ECOCOLLAGE_H_ */
