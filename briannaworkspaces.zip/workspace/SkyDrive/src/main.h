/*
 * main.h
 *
 *  Created on: Jun 18, 2013
 *      Author: brianna
 */

#ifndef MAIN_H_
#define MAIN_H_

namespace surf {

	class main {
	public:
		main();
		virtual ~main();
	};

} /* namespace surf */
#endif /* MAIN_H_ */
