/*
 * main.h
 *
 *  Created on: Jul 15, 2013
 *      Author: brianna
 */

#ifndef MAIN_H_
#define MAIN_H_

class main {
public:
	main();
	virtual ~main();
};

#endif /* MAIN_H_ */
